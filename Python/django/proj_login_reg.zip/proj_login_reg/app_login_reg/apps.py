from django.apps import AppConfig


class AppLoginRegConfig(AppConfig):
    name = 'app_login_reg'
